
-- Baroness Solitare
-- Created by Colin Cooper,  14st October 2018
-- 18/10/18 added hints, finger points to card combinations that can be paired

    supportedOrientations(WIDTH)
    displayMode(OVERLAY)
    displayMode( FULLSCREEN )

function setup()
rules = "Baroness is a solitaire card game that is played with a deck of 52 cards. Also known as Five Piles or Thirteens, it is a game that has an arrangement that is almost like that of Aces Up, but with the game play of Pyramid. \n Rules. \n Five cards are dealt in a row, they will form the bases of the five piles, the top cards of which are available for play.In order to win, one has to remove kings and pairs of cards that total 13. In this game, spotcards are taken at face value, Jacks value at 11,  Queens 12, Kings 13. So the following combinations of cards are discarded. \n Queen and Ace, \n Jack and 2, \n 10 and 3, \n 9 and 4, \n 8 and 5, \n 7 and 6, \n Kings on their own, \n When gaps occur, they are filled by the top cards of other piles, but when there are not enough cards to do this (less than five), cards from the stock are used. When gaps are filled and no Kings or other pairs of Card’s totalling 13 are present, five new cards are dealt from the stock, one on each pile. Game play then continues, with the top cards of each pile, as mentioned above, are available. This cycle of discarding and dealing of new cards goes on until the stock has been used up. The game is won when all cards have been discarded."

    GamesWon = readLocalData("GamesWon",0)
    GamesPlayed = readLocalData("GamesPlayed",0)
    Foundationinit = {0,13,26,39} -- initial foundation Ace cards
    RailTest = "Rail"
    DeckTest = "Deck"
    Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
    DisplayText = "Start: " 
    DisplayText2 = ""
    Deck.setup() -- setup the deck    
    Rail.deal() -- deal the cards to the rail
    GamesPlayed = GamesPlayed + 1  
    saveLocalData("GamesPlayed",GamesPlayed)   
    saved=true 
    WinnerTextSize = 10
    CardCount = 0
    KingCheck = false
end

function draw()
    collectgarbage() 
    background(40,40,50,1)
    ReStart.draw()
    Rules.draw()
    Deck.draw()
    WastePile.draw()
    Letters.draw()
    Hints.draw()
    HintPlays()
    Rail1Array.draw()
    Rail2Array.draw()
    Rail3Array.draw()
    Rail4Array.draw()
    Rail5Array.draw()
    if #WastePile == 52  then
        if  saved then
        DisplayText = "Congratulations you have Won!  "
        GamesWon = GamesWon + 1
        saveLocalData("GamesWon",GamesWon)
        DisplayText2=""
        saved = false
        ExplosionWin = true
        end
            if ExplosionWin then
                if WinnerTextSize>160 then
                    WinnerTextSize=160    
                else
                    WinnerTextSize = WinnerTextSize+1
                end
                fill(255, 0, 0, 255)
                fontSize(WinnerTextSize)
                text( "WINNER!",WIDTH/2, HEIGHT/2 )
            end
    end
end


-- Global variables
Deck = {}   --52 length array, holds cards in deck
Rail = {}  -- used to deal cards initially in the rail
Rules = {}
Rail1Array = {} --array to hold Rail index 1 cards when hidden by top card
Rail2Array = {} --array to hold Rail index 2 cards when hidden by top card
Rail3Array = {} --array to hold Rail index 3 cards when hidden by top card
Rail4Array = {} --array to hold Rail index 4 cards when hidden by top card
Rail5Array = {} --array to hold Rail index 5 cards when hidden by top card
WastePile = {} -- open ended array for the wastepile
ReStart = {}
WasteRail = {}
Letters = {}
Slide = {}
Array1Touched = false
Array2Touched = false
Array3Touched = false
Array4Touched = false
Array5Touched = false
rail1 = nil
suit1 = nil
rail2 = nil
suit2 = nil
Hints = {}
Hint1 = false
Hint2 = false
Hint3 = false
Hint4 = false
Hint5 = false
HintsRequired = false

local numberOfRanks = 13 -- Ace through to King
local numberOfSuits = 4
local width, height = 80,112  -- (50, 70) (70, 98) (80, 112) (90, 126) (100, 140)

local Rail1ArrayPosition =  vec2(300,450) 
local Rail2ArrayPosition =  vec2(400,450) 
local Rail3ArrayPosition =  vec2(500,450) 
local Rail4ArrayPosition =  vec2(600,450) 
local Rail5ArrayPosition =  vec2(700,450) 

local WastePilePosition =  vec2(800, 450) 

local AllPositions = {  
    -- base positions  one to five and removed Deck  , vec2(150, 450)
    vec2(300,450), vec2(400,450), vec2(500,450), vec2(600,450), vec2(700,450)}

local ReStartPosition = { vec2(WIDTH-100,HEIGHT-200) }

local RulesPosition = { vec2(WIDTH-100,HEIGHT-250) }

local HintPosition = { vec2(WIDTH-100,HEIGHT-350) }

local DeckPosition = vec2(200, 450) 

function HintPlays()
    if HintsRequired then
        if #Rail1Array > 0 and #Rail2Array > 0  then
            if (Rail1Array[#Rail1Array]%numberOfRanks+1) + (Rail2Array[#Rail2Array]%numberOfRanks+1) == 13 then
                Hint1 = true
                Hint2 = true
            elseif (Rail1Array[#Rail1Array]%numberOfRanks+1) == 13 then Hint1=true
            elseif (Rail2Array[#Rail2Array]%numberOfRanks+1) == 13 then Hint2=true
            end -- end ==13
            
        if #Rail1Array > 0 and #Rail3Array > 0  then
            if (Rail1Array[#Rail1Array]%numberOfRanks+1) + (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then
                Hint1 = true
                Hint3 = true
            elseif (Rail1Array[#Rail1Array]%numberOfRanks+1) == 13 then Hint1=true
            elseif (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then Hint3=true
            end -- end ==13
        end
        if #Rail1Array > 0 and #Rail4Array > 0  then
            if (Rail1Array[#Rail1Array]%numberOfRanks+1) + (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then
                Hint1 = true
                Hint4 = true
            elseif (Rail1Array[#Rail1Array]%numberOfRanks+1) == 13 then Hint1=true
            elseif (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then Hint4=true
            end -- end ==13
        end
        if #Rail1Array > 0 and #Rail5Array > 0  then
            if (Rail1Array[#Rail1Array]%numberOfRanks+1) + (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then
                Hint1 = true
                Hint5 = true
            elseif (Rail1Array[#Rail1Array]%numberOfRanks+1) == 13 then Hint1=true
            elseif (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then Hint5=true
            end -- end ==13
        end
        if #Rail1Array > 0 and #Rail5Array > 0  then
            if (Rail1Array[#Rail1Array]%numberOfRanks+1) + (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then
                Hint1 = true
                Hint5 = true
            elseif (Rail1Array[#Rail1Array]%numberOfRanks+1) == 13 then Hint1=true
            elseif (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then Hint5=true
            end -- end ==13
        end
        if #Rail2Array > 0 and #Rail3Array > 0  then
            if (Rail2Array[#Rail2Array]%numberOfRanks+1) + (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then
                Hint2 = true
                Hint3 = true
            elseif (Rail2Array[#Rail2Array]%numberOfRanks+1) == 13 then Hint2=true
            elseif (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then Hint3=true
            end -- end ==13
        end
        if #Rail2Array > 0 and #Rail4Array > 0  then
            if (Rail2Array[#Rail2Array]%numberOfRanks+1) + (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then
                Hint2 = true
                Hint4 = true
            elseif (Rail2Array[#Rail2Array]%numberOfRanks+1) == 13 then Hint2=true
            elseif (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then Hint4=true
            end -- end ==13
        end
        if #Rail2Array > 0 and #Rail5Array > 0  then
            if (Rail2Array[#Rail2Array]%numberOfRanks+1) + (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then
                Hint2 = true
                Hint5 = true
            elseif (Rail2Array[#Rail2Array]%numberOfRanks+1) == 13 then Hint2=true
            elseif (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then Hint5=true
            else 
            end -- end ==13
        end
        if #Rail3Array > 0 and #Rail4Array > 0  then
            if (Rail3Array[#Rail3Array]%numberOfRanks+1) + (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then
                Hint3 = true
                Hint4 = true
            elseif (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then Hint3=true
            elseif (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then Hint4=true
            end -- end ==13
        end
        if #Rail3Array > 0 and #Rail5Array > 0  then
            if (Rail3Array[#Rail3Array]%numberOfRanks+1) + (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then
                Hint3 = true
                Hint5 = true
            elseif (Rail3Array[#Rail3Array]%numberOfRanks+1) == 13 then Hint3=true
            elseif (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then Hint5=true
            end -- end ==13
        end
        if #Rail4Array > 0 and #Rail5Array > 0  then
            if (Rail4Array[#Rail4Array]%numberOfRanks+1) + (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then
                Hint4 = true
                Hint5 = true
            elseif (Rail4Array[#Rail4Array]%numberOfRanks+1) == 13 then Hint4=true
            elseif (Rail5Array[#Rail5Array]%numberOfRanks+1) == 13 then Hint5=true
            end -- end ==13
        end
        end -- end railarray
    else
        Hint1,Hint2,Hint4,Hint4,Hint5 = false,false,false,false,false
    end -- end hintsrequired
end

function Deck.setup()   --called in setup()
    for i = 1, 52 do
        Deck[i] = i
    end
    local j
    for i = 52, 2, -1 do
        j = math.random(52)
        Deck[i], Deck[j] = Deck[j], Deck[i]
    end
end

function Letters.draw()
        fontSize(32)
        fill(255, 154, 0, 255)
        text("Baroness",WIDTH/4*2,HEIGHT-100)
        fontSize(14)
        fill(247, 247, 247, 255)
        text(DisplayText,WIDTH/2,HEIGHT-40)
        text(DisplayText2,WIDTH/2,HEIGHT-80)
        text("Deck",DeckPosition.x,DeckPosition.y-height/4*3)
        text("Wastepile",WastePilePosition.x,WastePilePosition.y-height/4*3)
        text("You have won "..math.floor(GamesWon).." out of "..math.floor(GamesPlayed).." games",WIDTH/2,50)  
        DisplayText2 = "You have "..#Rail1Array+#Rail2Array+#Rail3Array+#Rail4Array+#Rail5Array+#Deck.." Cards left: "
        if HintsRequired then
            if #Deck==0 then
                if Hint1==false and Hint2==false and Hint3==false and Hint4==false and Hint5==false then
                    if #Rail1Array >0 and #Rail2Array >0 and #Rail3Array >0
                     and #Rail4Array >0 and #Rail5Array >0 then
                fontSize(40)
                fill(244, 9, 9, 255)
                text("No more valid moves",WIDTH/2,HEIGHT/2-100)  
                end
            end
        end
    end
end

function ReStart.draw()
    local mesh = mesh()
        mesh:addRect(ReStartPosition[1].x, ReStartPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(255, 0, 0, 255)
    fontSize(14) 
    text('Restart', ReStartPosition[1].x, ReStartPosition[1].y)
end

function Rules.draw()
    local mesh = mesh()
        mesh:addRect(RulesPosition[1].x, RulesPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(54, 148, 33, 255)
    fontSize(14) 
    text('Rules', RulesPosition[1].x, RulesPosition[1].y)
end

function Hints.draw()
    local mesh = mesh()
        mesh:addRect(HintPosition[1].x, HintPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(13, 11, 11, 255)
    fontSize(14) 
    text('Hints', HintPosition[1].x, HintPosition[1].y)
    fill(238, 238, 238, 255)
    if HintsRequired == false then
    text('Off', HintPosition[1].x, HintPosition[1].y+30)
    elseif HintsRequired == true then
    text('On', HintPosition[1].x, HintPosition[1].y+30)
    end
end

function WastePile.draw()
    local mesh=mesh()
    for i,v in ipairs(WastePile) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:CardBack"
        mesh:addRect(WastePilePosition.x, WastePilePosition.y, width, height)
    end
    mesh:draw()  
    mesh:clear()
    -- number of cards remaining in deck
    fill(8, 7, 7, 255)
    fontSize(32) 
    if #WastePile > 0 then
    text('#'..#WastePile, WastePilePosition.x, WastePilePosition.y)
    end
end

function Rail1Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail1Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array1Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail1ArrayPosition.x, Rail1ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail1ArrayPosition.x, Rail1ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    fill(249, 248, 248, 255)
    fontSize(16) 
    if #Rail1Array > 0 then
    text('#'..#Rail1Array, Rail1ArrayPosition.x, Rail1ArrayPosition.y-height/4*3)
    end
    if Hint1 then
    text('👇🏻', Rail1ArrayPosition.x, Rail1ArrayPosition.y+height/4*3)
    end
end

function Rail2Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail2Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array2Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail2ArrayPosition.x, Rail2ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail2ArrayPosition.x, Rail2ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw()
    mesh:clear()  
    fill(249, 248, 248, 255)
    fontSize(16) 
    if #Rail2Array > 0 then
    text('#'..#Rail2Array, Rail2ArrayPosition.x, Rail2ArrayPosition.y-height/4*3)
    end
    if Hint2 then
    text('👇🏻', Rail2ArrayPosition.x, Rail2ArrayPosition.y+height/4*3)
    end
end

function Rail3Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail3Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array3Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail3ArrayPosition.x, Rail3ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail3ArrayPosition.x, Rail3ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    fill(249, 248, 248, 255)
    fontSize(16) 
    if #Rail3Array > 0 then
    text('#'..#Rail3Array, Rail3ArrayPosition.x, Rail3ArrayPosition.y-height/4*3)
     end 
    if Hint3 then
    text('👇🏻', Rail3ArrayPosition.x, Rail3ArrayPosition.y+height/4*3)
    end
end

function Rail4Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail4Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array4Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail4ArrayPosition.x, Rail4ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail4ArrayPosition.x, Rail4ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    fill(249, 248, 248, 255)
    fontSize(16) 
    if #Rail4Array > 0 then
    text('#'..#Rail4Array, Rail4ArrayPosition.x, Rail4ArrayPosition.y-height/4*3)
    end
    if Hint4 then
    text('👇🏻', Rail4ArrayPosition.x, Rail4ArrayPosition.y+height/4*3)
    end
end

function Rail5Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail5Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array5Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail5ArrayPosition.x, Rail5ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail5ArrayPosition.x, Rail5ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear()  
    fill(249, 248, 248, 255)
    fontSize(16) 
    if #Rail5Array > 0 then
    text('#'..#Rail5Array, Rail5ArrayPosition.x, Rail5ArrayPosition.y-height/4*3)
    end
    if Hint5 then
    text('👇🏻', Rail5ArrayPosition.x, Rail5ArrayPosition.y+height/4*3)
    end
end


function Deck.draw()
    local mesh = mesh()
        mesh.texture = "Documents:CardBack"
        mesh:addRect(DeckPosition.x, DeckPosition.y, width, height)
    mesh:draw()
    mesh:clear()  
    -- number of cards remaining in deck
    fill(8, 7, 7, 255)
    fontSize(32) 
    text('#'..#Deck, DeckPosition.x, DeckPosition.y)
end

function Rail.deal()   --called to placed cards in Rail
        if #Deck ~= 0 then
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail2Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail3Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail4Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail5Array,Deck[#Deck])
        table.remove(Deck)
        end
end

function RailDealCheck()
    print("RailDealCheck")

            if #Rail1Array == 0 then -- if pile empty deal card from deck
                table.insert(Rail1Array,Deck[#Deck])
                table.remove(Deck)
            elseif #Rail2Array == 0 then
                table.insert(Rail2Array,Deck[#Deck])
                table.remove(Deck)
            elseif #Rail3Array == 0 then
                table.insert(Rail3Array,Deck[#Deck])
                table.remove(Deck)
            elseif #Rail4Array == 0 then
                table.insert(Rail4Array,Deck[#Deck])
                table.remove(Deck)
            elseif #Rail5Array == 0 then
                table.insert(Rail5Array,Deck[#Deck])
                table.remove(Deck)
            end
end


-- Rail.move defines the game rules,
function Rail.move(index1, index2) --called in Rail.touched(touch)
    CardCount = 0
    if index1 == 1 then
        --Rail1Array
        rank1 = Rail1Array[#Rail1Array]%numberOfRanks
        CardOrigin = RailTest
    elseif index1 == 2 then
        --Rail2Array
        rank1 = Rail2Array[#Rail2Array]%numberOfRanks
        CardOrigin = RailTest
    elseif index1 == 3 then
        --Rail3Array
        rank1 = Rail3Array[#Rail3Array]%numberOfRanks
        CardOrigin = RailTest
    elseif index1 == 4 then
        --Rail4Array
        rank1 = Rail4Array[#Rail4Array]%numberOfRanks
        CardOrigin = RailTest
    elseif index1 == 5 then
        --Rail5Array
        rank1 = Rail5Array[#Rail5Array]%numberOfRanks
        CardOrigin = RailTest
    elseif index1 == 6 then -- origin is Deck
        rank1 = Deck[#Deck]%numberOfRanks
        CardOrigin = DeckTest
    end

    if KingCheck then
        rank2 = -1
        CardDestination = RailTest
        index2 = nil
        KingCheck = false
    else
        if index2 == 1 and #Rail1Array == 0 or  index2 == 2 and #Rail2Array == 0 or 
            index2 == 3 and #Rail3Array == 0 or index2 == 4 and #Rail4Array == 0 or 
            index2 == 5 and #Rail5Array == 0 then
        DisplayText = "you cant tap cards into blank positions, please slide the card"
            Test2 = 1
        else
            if index2 == 1 then
                --Rail1Array
                rank2 = Rail1Array[#Rail1Array]%numberOfRanks
                CardDestination = RailTest
            elseif index2 == 2 then
                --Rail2Array
                rank2 = Rail2Array[#Rail2Array]%numberOfRanks
                CardDestination = RailTest
            elseif index2 == 3 then
                --Rail3Array
                rank2 = Rail3Array[#Rail3Array]%numberOfRanks
                CardDestination = RailTest
            elseif index2 == 4 then
                --Rail4Array
                rank2 = Rail4Array[#Rail4Array]%numberOfRanks
                CardDestination = RailTest
            elseif index2 == 5 then
                --Rail5Array
                rank2 = Rail5Array[#Rail5Array]%numberOfRanks
                CardDestination = RailTest
            end
        end

    end

if Test2 == 1 then
-- just display test 2 error code        
    else
-- test if movement of the card is permitted    
    if (rank1+1)+(rank2+1)~= 13  then
                DisplayText = "Invalid Move. card totals must equal 13." 
                Test1 = 1            
    end
end
    
if Test1+Test2>0 then
-- if any test returns a 1 then the card moving routine does not activate        
        Test1, Test2 = 0,0   -- reset the tests  
else -- move the cards
        DisplayText = ""
            RailFilled = 0
            if CardOrigin == RailTest then
                    if CardDestination == RailTest then
-- origin Rail destination Rail
                    i = index1 -- source
                    j = index2 -- destination
                        if j == 1 then
                                if i == 2 then
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.remove(Rail1Array)
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.remove(Rail1Array)
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.remove(Rail1Array)
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.remove(Rail1Array)
                                table.remove(Rail5Array)
                                end
                        elseif j == 2 then
                                if i == 1 then
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.remove(Rail2Array)
                                table.remove(Rail1Array)
                                elseif i == 3 then
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.remove(Rail2Array)
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.remove(Rail2Array)
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.remove(Rail2Array)
                                table.remove(Rail5Array)
                                end
                        elseif j == 3 then
                                if i == 1 then
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.remove(Rail3Array)
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.remove(Rail3Array)
                                table.remove(Rail2Array)
                                elseif i == 4 then
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.remove(Rail3Array)
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.remove(Rail3Array)
                                table.remove(Rail5Array)
                                end
                        elseif j == 4 then
                                if i == 1 then
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.remove(Rail4Array)
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.remove(Rail4Array)
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.remove(Rail4Array)
                                table.remove(Rail3Array)
                                elseif i == 5 then
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.remove(Rail4Array)
                                table.remove(Rail5Array)
                                end
                        elseif j == 5 then
                                if i == 1 then
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.remove(Rail5Array)
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.remove(Rail5Array)
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.remove(Rail5Array)
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.remove(Rail5Array)
                                table.remove(Rail4Array)
                                end
                    elseif j == nil then
                                if i == 1 then
                                table.insert(WastePile, Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(WastePile, Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(WastePile, Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(WastePile, Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(WastePile, Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                end
                     end  
                end
        end
    end
     Hint1,Hint2,Hint3,Hint4,Hint5 = false,false,false,false,false
end    

function Rail.slide(index1, index2) --called in Rail.touched(touch)
    if CardCount == 3 then
        if #Rail1Array == 0 or #Rail2Array == 0 or #Rail3Array == 0 or #Rail4Array == 0 or #Rail5Array == 0 then
                DisplayText = ""
                if CardOrigin == RailTest then
                        if CardDestination == RailTest then
                        -- origin Rail destination Rail
                        i = index1 -- source
                        j = index2 -- destination
                            if j == 1 then
                                    if i == 2 then
                                    table.insert(Rail1Array, Rail2Array[#Rail2Array])
                                    table.remove(Rail2Array)
                                    elseif i == 3 then
                                    table.insert(Rail1Array, Rail3Array[#Rail3Array])
                                    table.remove(Rail3Array)
                                    elseif i == 4 then
                                    table.insert(Rail1Array, Rail4Array[#Rail4Array])
                                    table.remove(Rail4Array)
                                    elseif i == 5 then
                                    table.insert(Rail1Array, Rail5Array[#Rail5Array])
                                    table.remove(Rail5Array)
                                    end
                            elseif j == 2 then
                                    if i == 1 then
                                    table.insert(Rail2Array, Rail1Array[#Rail1Array])
                                    table.remove(Rail1Array)
                                    elseif i == 3 then
                                    table.insert(Rail2Array, Rail3Array[#Rail3Array])
                                    table.remove(Rail3Array)
                                    elseif i == 4 then
                                    table.insert(Rail2Array, Rail4Array[#Rail4Array])
                                    table.remove(Rail4Array)
                                    elseif i == 5 then
                                    table.insert(Rail2Array, Rail5Array[#Rail5Array])
                                    table.remove(Rail5Array)
                                    end
                            elseif j == 3 then
                                    if i == 1 then
                                    table.insert(Rail3Array, Rail1Array[#Rail1Array])
                                    table.remove(Rail1Array)
                                    elseif i == 2 then
                                    table.insert(Rail3Array, Rail2Array[#Rail2Array])
                                    table.remove(Rail2Array)
                                    elseif i == 4 then
                                    table.insert(Rail3Array, Rail4Array[#Rail4Array])
                                    table.remove(Rail4Array)
                                    elseif i == 5 then
                                    table.insert(Rail3Array, Rail5Array[#Rail5Array])
                                    table.remove(Rail5Array)
                                    end
                            elseif j == 4 then
                                    if i == 1 then
                                    table.insert(Rail4Array, Rail1Array[#Rail1Array])
                                    table.remove(Rail1Array)
                                    elseif i == 2 then
                                    table.insert(Rail4Array, Rail2Array[#Rail2Array])
                                    table.remove(Rail2Array)
                                    elseif i == 3 then
                                    table.insert(Rail4Array, Rail3Array[#Rail3Array])
                                    table.remove(Rail3Array)
                                    elseif i == 5 then
                                    table.insert(Rail4Array, Rail5Array[#Rail5Array])
                                    table.remove(Rail5Array)
                                    end
                            elseif j == 5 then
                                    if i == 1 then
                                    table.insert(Rail5Array, Rail1Array[#Rail1Array])
                                    table.remove(Rail1Array)
                                    elseif i == 2 then
                                    table.insert(Rail5Array, Rail2Array[#Rail2Array])
                                    table.remove(Rail2Array)
                                    elseif i == 3 then
                                    table.insert(Rail5Array, Rail3Array[#Rail3Array])
                                    table.remove(Rail3Array)
                                    elseif i == 4 then
                                    table.insert(Rail5Array, Rail4Array[#Rail4Array])
                                    table.remove(Rail4Array)
                                    end
                            end -- if j ended
                         end -- if card destination ended 
                    end -- if card origin ended
        else 
                DisplayText = "Invalid Move. you cant move cards onto non empty piles." 
                Test1 = 1            
            CardCount = 0  

        end -- if railarrays ended
        CardCount = 0
     end -- if cardcount ended
end --function ended
    
function touched(touch)
    ReStart.touched(touch)
    Rules.touched(touch)
    Deck.touched(touch)
    Slide.touched(touch)
    Hints.touched(touch)
    for i,v in ipairs(AllPositions) do
        if touch.x > v.x - width*.5 and touch.x < v.x + width*.5
                and touch.y > v.y - height*.5 and touch.y < v.y + height*.5 then

            if touch.tapCount == 1 and touch.state == ENDED then
                if CardCount == 0 then
               index1 = i
                -- if statement for arrays needed
                    if index1 == 1 then
                    Array1Touched = true
                    elseif index1 == 2 then
                    Array2Touched = true
                    elseif index1 == 3 then
                    Array3Touched = true
                    elseif index1 == 4 then
                    Array4Touched = true
                    elseif index1 == 5 then
                    Array5Touched = true
                    end
                    CardCount = 1
                        if index1 == 1 then
                            --Rail1Array
                            rank1 = Rail1Array[#Rail1Array]%numberOfRanks
                            CardOrigin = RailTest
                        elseif index1 == 2 then
                            --Rail2Array
                            rank1 = Rail2Array[#Rail2Array]%numberOfRanks
                            CardOrigin = RailTest
                        elseif index1 == 3 then
                            --Rail3Array
                            rank1 = Rail3Array[#Rail3Array]%numberOfRanks
                            CardOrigin = RailTest
                        elseif index1 == 4 then
                            --Rail4Array
                            rank1 = Rail4Array[#Rail4Array]%numberOfRanks
                            CardOrigin = RailTest
                        elseif index1 == 5 then
                            --Rail5Array
                            rank1 = Rail5Array[#Rail5Array]%numberOfRanks
                            CardOrigin = RailTest
                        elseif index1 == 6 then -- origin is Deck
                            rank1 = Deck[#Deck]%numberOfRanks
                            CardOrigin = DeckTest
                        end
                        if rank1 == 12 then
                            KingCheck = true
                            CardCount = 0
                            Array1Touched, Array2Touched, Array3Touched, Array4Touched, Array5Touched = 
                                false, false, false, false, false
                            Rail.move(index1, index2)
                        end
                        break
                elseif CardCount == 1 then
                    index2 = i 
                    if index2 == 1 then
                    Array1Touched = true
                    elseif index2 == 2 then
                    Array2Touched = true
                    elseif index2 == 3 then
                    Array3Touched = true
                    elseif index2 == 4 then
                    Array4Touched = true
                    elseif index2 == 5 then
                    Array5Touched = true
                    end
                    CardCount = 2
                    Array1Touched, Array2Touched, Array3Touched, Array4Touched, Array5Touched = 
                        false, false, false, false, false
                    Rail.move(index1, index2)
                end
            end
        end
    end
end

function Slide.touched(touch)
    for i,v in ipairs(AllPositions) do
        if touch.x > v.x - width*.5 and touch.x < v.x + width*.5
                and touch.y > v.y - height*.5 and touch.y < v.y + height*.5 then
            if touch.state == BEGAN and CardCount == 0  then
                index1 = i
                break
            elseif touch.state == ENDED and CardCount ==0 then
                index2 = i
                if index1 and index2 and index1 ~= index2 then
                    CardCount = 3
                    Rail.slide(index1, index2)
                end
                index1, index2 = nil, nil
                break
            end
        end
    end
end

function Deck.touched(touch)    --called in touched(touch)
    if touch.x > DeckPosition.x - width*.5 and touch.x < DeckPosition.x + width*.5
    and touch.y > DeckPosition.y - height*.5 and touch.y < DeckPosition.y + height*.5
    and touch.state == ENDED then
        if #Deck ~= 0 then
            if #Rail1Array == 0 or #Rail2Array == 0
                 or #Rail3Array == 0 or #Rail4Array == 0 or #Rail5Array == 0 then
                RailDealCheck()
            else
                Rail.deal() 
            end 
        end  
    end
end

function Rules.touched(touch)    --called in touched(touch)
    for i,v in ipairs(RulesPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
            alert(rules, "Game Rules")
            end
        end
    end
end

function Hints.touched(touch)    --called in touched(touch)
    for i,v in ipairs(HintPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
                if HintsRequired == true then
                    HintsRequired = false
                elseif HintsRequired == false then
                    HintsRequired = true
                end
            end
        end
    end
end

function ReStart.touched(touch) 
    for i,v in ipairs(ReStartPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then

            if touch.tapCount == 1 and touch.state == ENDED then
                if #Deck == 0 then
                    GamesWon = readLocalData("GamesWon",0)
                    GamesPlayed = readLocalData("GamesPlayed",0)
                    for i = 1, #Rail1Array do
                        table.remove(Rail1Array)
                    end
                    for i = 1, #Rail2Array do
                        table.remove(Rail2Array)
                    end
                    for i = 1, #Rail3Array do
                        table.remove(Rail3Array)
                    end
                    for i = 1, #Rail4Array do
                        table.remove(Rail4Array)
                    end
                    for i = 1, #Rail5Array do
                        table.remove(Rail5Array)
                    end
                    for i = 1, #WastePile do
                        table.remove(WastePile)
                    end
                    for i = 1, #Deck do
                        table.remove(Deck)
                    end
                    RailTest = "Rail"
                    Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
                    DisplayText = "Start: " 
                    Deck.setup() -- setup the deck
                    -- deal the cards to the rail
                    Rail.deal(i)
                    saved=true 
                    WinnerTextSize = 10
                    GamesPlayed = GamesPlayed + 1 
                    saveLocalData("GamesPlayed",GamesPlayed)  
                    ExplosionWin = false
                else
                        DisplayText = "Finish your game before restarting"
                end
            end
        end
    end
end
