
-- Royal Flush Solitare
-- Created by Colin Cooper,  21st October 2018

    supportedOrientations(WIDTH)
    displayMode(OVERLAY)
    displayMode( FULLSCREEN )

function setup()
rules = "Royal Flush is a solitaire card game which is played with a deck of 52 playing cards. The game is so called because the aim of the game is to end up with a royal flush of any suit. \n First, the deck is dealt into five piles: two piles of eleven cards and three piles of ten.  \n The player turns the first pile up and looks for either an ace, a ten, a king, a queen, or a jack, cards which comprise a royal flush.  \n Once such a card is found, the search ends there, with the cards on top of it discarded and those under it left alone. The search then proceeds into the next pile and the search for other cards in the royal flush continues.  \n Also, the suit of the first card found determines the suit of the entire royal flush. When a pile contains no card of the royal flush being searched, the entire pile is discarded. When another royal-flush card is found in a pile, the search continues until all five piles are searched and royal-flush cards are at the top of their piles.  \n Afterwards, the piles are placed on top of each other in the reverse direction of the deal. So each pile is placed on its neighbor to the left. The discarded cards are set aside. Then without shuffling, the remaining cards are dealt this time into four piles. After this, the search the cards of the royal flush begins again with the same procedure already stated above. Once all four piles are searched and regathered, the remaining cards (again without reshuffling) are dealt into three piles. The process continues, and after the gathering of the piles, the cards are dealt into two piles and the procedure begins once more. When the two piles are regathered, the remaining cards at this point are then dealt into a single pile. Even at this point, the search stops when a royal-flush card is found and the cards on top of it are discarded. The game is won when the cards of the royal flush are the only ones left in the pile and are arranged in any order. If there are any other cards sandwiched among the royal flush cards, the game is lost."

    GamesWon = readLocalData("GamesWon",0)
    GamesPlayed = readLocalData("GamesPlayed",0)
    Foundationinit = {0,13,26,39} -- initial foundation Ace cards
    RailTest = "Rail"
    DeckTest = "Deck"
    Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
    DisplayText = "Start: " 
    DisplayText2 = ""
    Deck.setup() -- setup the deck    
    Rail.deal() -- deal the cards to the rail
    GamesPlayed = GamesPlayed + 1  
    saveLocalData("GamesPlayed",GamesPlayed)   
    saved=true 
    WinnerTextSize = 10
    CardCount = 0
    KingCheck = false
    blanktest = 0
    GameWinCheck = 0
    rankTest1 = 0
    rankTest2 = 0
    rankTest3 = 0
    rankTest4 = 0
    rankTest5 = 0
end

function draw()
    collectgarbage() 
    background(40,40,50,1)
    ReStart.draw()
    Rules.draw()
    WastePile.draw()
    Letters.draw()
    Rail1Array.draw()
    Rail2Array.draw()
    Rail3Array.draw()
    Rail4Array.draw()
    Rail5Array.draw()
    if GameWinCheck == 1  then
        if  saved then
        DisplayText = "Game Finished!  "
        GamesWon = GamesWon + 1
        saveLocalData("GamesWon",GamesWon)
        DisplayText2=""
        saved = false

        end
            if ExplosionWin then
                if WinnerTextSize>160 then
                    WinnerTextSize=160    
                else
                    WinnerTextSize = WinnerTextSize+1
                end
                fill(255, 0, 0, 255)
                fontSize(WinnerTextSize)
                font("AmericanTypewriter")
                text( "WINNER!",WIDTH/2, HEIGHT/2-100 )
            else
                if WinnerTextSize>160 then
                    WinnerTextSize=160    
                else
                    WinnerTextSize = WinnerTextSize+1
                end
                fill(255, 0, 0, 255)
                fontSize(WinnerTextSize)
                font("AmericanTypewriter")
                text( "Sorry no Win!",WIDTH/2, HEIGHT/2-100 )
            end
    end
end

-- Global variables
Deck = {}   --52 length array, holds cards in deck
Rail = {}  -- used to deal cards initially in the rail
Rules = {}
Rail1Array = {} 
Rail2Array = {} 
Rail3Array = {} 
Rail4Array = {} 
Rail5Array = {} 
WastePile = {} 
ReStart = {}
WasteRail = {}
Letters = {}
Slide = {}
Array1Touched = false
Array2Touched = false
Array3Touched = false
Array4Touched = false
Array5Touched = false
rank1 = nil
suit1 = nil
RoyalSuit = nil
DealNumber = 0

local numberOfRanks = 13 -- Ace through to King
local numberOfSuits = 4
local width, height = 100,140  -- (50, 70) (70, 98) (80, 112) (90, 126) (100, 140)
local Rail1ArrayPosition =  vec2(260,400) 
local Rail2ArrayPosition =  vec2(370,400) 
local Rail3ArrayPosition =  vec2(480,400) 
local Rail4ArrayPosition =  vec2(590,400) 
local Rail5ArrayPosition =  vec2(700,400) 
local WastePilePosition  =  vec2(810, 400) 

local AllPositions = 
    { Rail1ArrayPosition, Rail2ArrayPosition, Rail3ArrayPosition, Rail4ArrayPosition, Rail5ArrayPosition }

local ReStartPosition = { vec2(WIDTH-100,HEIGHT-200) }
local RulesPosition = { vec2(WIDTH-100,HEIGHT-250) }

function Deck.setup()   --called in setup()
    for i = 1, 52 do
        Deck[i] = i
    end
    local j
    for i = 52, 2, -1 do
        j = math.random(52)
        Deck[i], Deck[j] = Deck[j], Deck[i]
    end
end

function Letters.draw()
        fontSize(32)
        fill(255, 154, 0, 255)
        text("Royal Flush",WIDTH/4*2,HEIGHT-150)
        fontSize(22)
        fill(247, 247, 247, 255)
        text(DisplayText,WIDTH/2,HEIGHT-40)
        text(DisplayText2,WIDTH/2,HEIGHT-80)
        text("Wastepile",WastePilePosition.x,WastePilePosition.y-height/4*3)
        text("You have won "..math.floor(GamesWon).." out of "..math.floor(GamesPlayed).." games",WIDTH/2,50)  
        DisplayText2 = "Deal Number "..DealNumber
        if RoyalSuit == 0 then
        fontSize(22)
        text("Suit is Spades",WIDTH/2, HEIGHT-200)
        elseif RoyalSuit == 1 then
        fontSize(22)
        text("Suit is Hearts",WIDTH/2, HEIGHT-200)
        elseif RoyalSuit == 2 then
        fontSize(22)
        text("Suit is Diamonds",WIDTH/2, HEIGHT-200)
        elseif RoyalSuit == 3 then
        fontSize(22)
        text("Suit is Clubs",WIDTH/2, HEIGHT-200)
        else
        text("",WIDTH/2, HEIGHT-100)
    end
end

function ReStart.draw()
    local mesh = mesh()
        mesh:addRect(ReStartPosition[1].x, ReStartPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(255, 0, 0, 255)
    fontSize(14) 
    text('Restart', ReStartPosition[1].x, ReStartPosition[1].y)
end

function Rules.draw()
    local mesh = mesh()
        mesh:addRect(RulesPosition[1].x, RulesPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(54, 148, 33, 255)
    fontSize(14) 
    text('Rules', RulesPosition[1].x, RulesPosition[1].y)
end

function WastePile.draw()
    local mesh=mesh()
    for i,v in ipairs(WastePile) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:CardBack"
        mesh:addRect(WastePilePosition.x, WastePilePosition.y, width, height)
    end
    mesh:draw()  
    mesh:clear()
    fill(8, 7, 7, 255)
    fontSize(32) 
    if #WastePile > 0 then
    text('#'..#WastePile, WastePilePosition.x, WastePilePosition.y)
    end
end

function Rail1Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail1Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array1Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail1ArrayPosition.x, Rail1ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail1ArrayPosition.x, Rail1ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    if Array1Touched then
        fontSize(16) 
        fill(253, 253, 253, 255)
        text('☑️', Rail1ArrayPosition.x, Rail1ArrayPosition.y+height/4*3)
    else
        text('', Rail1ArrayPosition.x, Rail1ArrayPosition.y+height/4*3)
    end
end

function Rail2Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail2Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array2Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail2ArrayPosition.x, Rail2ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail2ArrayPosition.x, Rail2ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw()
    mesh:clear()  
    if Array2Touched then
        fontSize(16) 
        fill(253, 253, 253, 255)
        text('☑️', Rail2ArrayPosition.x, Rail2ArrayPosition.y+height/4*3)
    else
        text('', Rail2ArrayPosition.x, Rail2ArrayPosition.y+height/4*3)
    end
end

function Rail3Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail3Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array3Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail3ArrayPosition.x, Rail3ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail3ArrayPosition.x, Rail3ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    if Array3Touched then
        fontSize(16) 
        fill(253, 253, 253, 255)
        text('☑️', Rail3ArrayPosition.x, Rail3ArrayPosition.y+height/4*3)
    else
        text('', Rail3ArrayPosition.x, Rail3ArrayPosition.y+height/4*3)
    end
end

function Rail4Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail4Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array4Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail4ArrayPosition.x, Rail4ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail4ArrayPosition.x, Rail4ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    if Array4Touched then
        fontSize(16) 
        fill(253, 253, 253, 255)
        text('☑️', Rail4ArrayPosition.x, Rail4ArrayPosition.y+height/4*3)
    else
        text('', Rail4ArrayPosition.x, Rail4ArrayPosition.y+height/4*3)
    end
end

function Rail5Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail5Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        if Array5Touched then
        mesh.texture = "Documents:SheetTouched"
        mesh:addRect(Rail5ArrayPosition.x, Rail5ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        else
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail5ArrayPosition.x, Rail5ArrayPosition.y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
        end
    end
    mesh:draw() 
    mesh:clear() 
    if Array5Touched then
        fontSize(16) 
        fill(253, 253, 253, 255)
        text('☑️', Rail5ArrayPosition.x, Rail5ArrayPosition.y+height/4*3)
    else
        text('', Rail5ArrayPosition.x, Rail5ArrayPosition.y+height/4*3)
    end
end


function Deck.draw()
    local mesh = mesh()
        mesh.texture = "Documents:CardBack"
        mesh:addRect(DeckPosition.x, DeckPosition.y, width, height)
    mesh:draw()
    mesh:clear()  
    -- number of cards remaining in deck
    fill(8, 7, 7, 255)
    fontSize(32) 
    text('#'..#Deck, DeckPosition.x, DeckPosition.y)
end

function Rail.Stack()
    if DealNumber == 1 then
            for i = 1, #Rail1Array do
                table.insert(Deck,Rail1Array[1])
                table.remove(Rail1Array, 1)
            end
            for i = 1, #Rail2Array do
                table.insert(Deck,Rail2Array[1])
                table.remove(Rail2Array, 1)
            end
            for i = 1, #Rail3Array do
                table.insert(Deck,Rail3Array[1])
                table.remove(Rail3Array, 1)
            end
            for i = 1, #Rail4Array do
                table.insert(Deck,Rail4Array[1])
                table.remove(Rail4Array, 1)
            end
            for i = 1, #Rail5Array do
                table.insert(Deck,Rail5Array[1])
                table.remove(Rail5Array, 1)
            end
    elseif DealNumber == 2 then
            for i = 1, #Rail1Array do
                table.insert(Deck,Rail1Array[1])
                table.remove(Rail1Array, 1)
            end
            for i = 1, #Rail2Array do
                table.insert(Deck,Rail2Array[1])
                table.remove(Rail2Array, 1)
            end
            for i = 1, #Rail3Array do
                table.insert(Deck,Rail3Array[1])
                table.remove(Rail3Array, 1)
            end
            for i = 1, #Rail4Array do
                table.insert(Deck,Rail4Array[1])
                table.remove(Rail4Array, 1)
            end        
    elseif DealNumber == 3 then
            for i = 1, #Rail1Array do
                table.insert(Deck,Rail1Array[1])
                table.remove(Rail1Array, 1)
            end
            for i = 1, #Rail2Array do
                table.insert(Deck,Rail2Array[1])
                table.remove(Rail2Array, 1)
            end
            for i = 1, #Rail3Array do
                table.insert(Deck,Rail3Array[1])
                table.remove(Rail3Array, 1)
            end
    elseif DealNumber == 4 then
            for i = 1, #Rail1Array do
                table.insert(Deck,Rail1Array[1])
                table.remove(Rail1Array, 1)
            end
            for i = 1, #Rail2Array do
                table.insert(Deck,Rail2Array[1])
                table.remove(Rail2Array, 1)
            end
    elseif DealNumber == 5 then
                table.insert(Rail5Array,Rail1Array[1])
                table.remove(Rail1Array, 1)
                table.insert(Rail4Array,Rail1Array[1])
                table.remove(Rail1Array, 1)
                table.insert(Rail3Array,Rail1Array[1])
                table.remove(Rail1Array, 1)
                table.insert(Rail2Array,Rail1Array[1])
                table.remove(Rail1Array, 1)
    end
                    Rail.deal() 
end

function Rail.deal()   --called to placed cards in Rail
DealNumber = DealNumber + 1

    if DealNumber == 1 then -- inital deal
        for i = 1, 11 do
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail2Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail3Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail4Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail5Array,Deck[#Deck])
        table.remove(Deck)
        end
    elseif DealNumber == 2 then
        j = #Deck
        for i = 1, j do
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail2Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail3Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail4Array,Deck[#Deck])
        table.remove(Deck)
        end        
    elseif DealNumber == 3 then
        j = #Deck
        for i = 1, j do
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail2Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail3Array,Deck[#Deck])
        table.remove(Deck)
        end
    elseif DealNumber == 4 then
        j = #Deck
        for i = 1, j do
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        table.insert(Rail2Array,Deck[#Deck])
        table.remove(Deck)
        end
    elseif DealNumber == 5 then
        j = #Deck
        for i = 1, j do
        table.insert(Rail1Array,Deck[#Deck])
        table.remove(Deck)
        end
    elseif DealNumber == 6 then
        GameWinChecker()
    end
end

function GameWinChecker()
        rank1, suit1 = Rail1Array[#Rail1Array]%numberOfRanks, Rail1Array[#Rail1Array]%numberOfSuits
        rank2, suit2 = Rail2Array[#Rail2Array]%numberOfRanks, Rail2Array[#Rail2Array]%numberOfSuits
        rank3, suit3 = Rail3Array[#Rail3Array]%numberOfRanks, Rail3Array[#Rail3Array]%numberOfSuits
        rank4, suit4 = Rail4Array[#Rail4Array]%numberOfRanks, Rail4Array[#Rail4Array]%numberOfSuits
        rank5, suit5 = Rail5Array[#Rail5Array]%numberOfRanks, Rail5Array[#Rail5Array]%numberOfSuits

if suit1 == RoyalSuit and suit2 == RoyalSuit and suit3 == RoyalSuit and suit4 == RoyalSuit and suit5 == RoyalSuit then
        if rank1 == 0 or rank1 > 8 then rankTest1 = 1 end
        if rank2 == 0 or rank2 > 8 then rankTest2 = 1 end
        if rank3 == 0 or rank3 > 8 then rankTest3 = 1 end
        if rank4 == 0 or rank4 > 8 then rankTest4 = 1 end
        if rank5 == 0 or rank5 > 8 then rankTest5 = 1 end
    else
        rankTest1,rankTest2,rankTest3,rankTest4,rankTest5 = 0,0,0,0,0
    end

        if rankTest1+rankTest2+rankTest3+rankTest4+rankTest5 == 5 then
            GameWinCheck = 1
            ExplosionWin = true
            rankTest1,rankTest2,rankTest3,rankTest4,rankTest5 = 0,0,0,0,0
        else
            GameWinCheck = 1
            ExplosionWin = false
            rankTest1,rankTest2,rankTest3,rankTest4,rankTest5 = 0,0,0,0,0
        end
end

-- Rail.move defines the game rules,
function Rail.move(index1, index2) --called in Rail.touched(touch)
--test 5
                        if index1 == 1 and #Rail1Array == 0 then
                            Test5 = 1
                        elseif index1 == 2 and #Rail2Array == 0 then
                            Test5 = 2
                        elseif index1 == 3 and #Rail3Array == 0 then
                            Test5 = 3
                        elseif index1 == 4 and #Rail4Array == 0 then
                            Test5 = 4
                        elseif index1 == 5 and #Rail5Array == 0 then
                            Test5 = 5
                        end
if Test5 > 0 then
        DisplayText = "you cant select a blank pile"
else
                    
    if index1 == 1 then
        --Rail1Array
        rank1, suit1 = Rail1Array[#Rail1Array]%numberOfRanks, Rail1Array[#Rail1Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 2 then
        --Rail2Array
        rank1, suit1 = Rail2Array[#Rail2Array]%numberOfRanks, Rail2Array[#Rail2Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 3 then
        --Rail3Array
        rank1, suit1 = Rail3Array[#Rail3Array]%numberOfRanks, Rail3Array[#Rail3Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 4 then
        --Rail4Array
        rank1, suit1 = Rail4Array[#Rail4Array]%numberOfRanks, Rail4Array[#Rail4Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 5 then
        --Rail5Array
        rank1, suit1 = Rail5Array[#Rail5Array]%numberOfRanks, Rail5Array[#Rail5Array]%numberOfSuits
        CardOrigin = RailTest
    end
end

    --Test 1  
    if Array1Touched and index1 == 1 then
        Test1 = 1
        DisplayText = "once a Royal Flush card is selected then you cant not discard"
    elseif Array2Touched and index1 == 2 then
        Test1 = 1
        DisplayText = "once a Royal Flush card is selected then you cant not discard"
    elseif Array3Touched and index1 == 3 then
        Test1 = 1
        DisplayText = "once a Royal Flush card is selected then you cant not discard"
    elseif Array4Touched and index1 == 4 then
        Test1 = 1
        DisplayText = "once a Royal Flush card is selected then you cant not discard"
    elseif Array5Touched and index1 == 5 then
        Test1 = 1
        DisplayText = "once a Royal Flush card is selected then you cant not discard"
    end
    
    -- Test 2
    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
        if index1 == 1 and Array1Touched == false and DealNumber == 1 then 
            RoyalSuit = suit1
            Array1Touched = true
            DisplayText = "Royal Flush suit selected"
            Test2 = 1        
        elseif suit1 == RoyalSuit then
                if index1 == 1 and Array1Touched == false and DealNumber~=1 then
                    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
                        Array1Touched = true
                        DisplayText = "First Royal Flush card selected"
                        Test2 = 1
                        if DealNumber == 5 then
                        Array1Touched=false
                        Rail.Stack()
                        end
                    end
                elseif index1 == 2 and Array2Touched == false then
                    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
                        Array2Touched = true
                        DisplayText = "Second Royal Flush card selected"
                        Test2 = 2
                        if DealNumber == 4 then
                        Array1Touched,Array2Touched=false,false
                        Rail.Stack()
                        end
                    end
                elseif index1 == 3 and Array3Touched == false then
                    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
                        Array3Touched = true
                        DisplayText = "Third Royal Flush card selected"
                        Test2 = 3
                        if DealNumber == 3 then
                        Array1Touched,Array2Touched,Array3Touched=false,false,false
                        Rail.Stack()
                        end
                    end
                elseif index1 == 4 and Array4Touched == false then
                    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
                        Array4Touched = true
                        DisplayText = "Fourth Royal Flush card selected"
                        Test2 = 4
                        if DealNumber == 2 then
                        Array1Touched,Array2Touched,Array3Touched,Array4Touched=false,false,false,false
                        Rail.Stack()
                        end
                    end
                elseif index1 == 5 and Array5Touched == false then
                    if rank1+1 == 1 or rank1+1 == 10 or rank1+1 == 11 or rank1+1 == 12 or rank1+1 == 13 then
                        Array5Touched = true
                        DisplayText = "Fifth Royal Flush card selected"
                        Test2 = 5
                    Array1Touched,Array2Touched,Array3Touched,Array4Touched,Array5Touched=false,false,false,false,false
                    end
                    Rail.Stack()
                end
        end
    end
    -- Test 3
    if Array1Touched == false and index1 ~= 1 then
        DisplayText = "You must select cards from the first pile on the left first"
        Test3 = 1
    end
    
    if Test1+Test2+Test3+Test4+Test5 > 0 then
        -- if any test returns a 1 then the card moving routine does not activate        
            Test1, Test2, Test3, Test4, Test5 = 0,0,0,0,0  -- reset the tests, except test 2
    else -- move the cards
            DisplayText = ""
                RailFilled = 0

            if DealNumber == 1 then
                i = index1 -- source                
                if i == 1 then
                table.insert(WastePile, Rail1Array[#Rail1Array])
                table.remove(Rail1Array)
                elseif i == 2 then
                table.insert(WastePile, Rail2Array[#Rail2Array])
                table.remove(Rail2Array)
                elseif i == 3 then
                table.insert(WastePile, Rail3Array[#Rail3Array])
                table.remove(Rail3Array)
                elseif i == 4 then
                table.insert(WastePile, Rail4Array[#Rail4Array])
                table.remove(Rail4Array)
                elseif i == 5 then
                table.insert(WastePile, Rail5Array[#Rail5Array])
                table.remove(Rail5Array)
                -- check if array is empty

                    if #Rail5Array == 0 then
                    Array1Touched,Array2Touched,Array3Touched,Array4Touched,Array5Touched=false,false,false,false,false
                    Rail.Stack()

                    end
                end 
            elseif DealNumber == 2 then
                    i = index1 -- source                
                    if i == 1 then
                        table.insert(WastePile, Rail1Array[#Rail1Array])
                        table.remove(Rail1Array)
                    elseif i == 2 then
                        table.insert(WastePile, Rail2Array[#Rail2Array])
                        table.remove(Rail2Array)
                    elseif i == 3 then
                        table.insert(WastePile, Rail3Array[#Rail3Array])
                        table.remove(Rail3Array)
                    elseif i == 4 then
                        table.insert(WastePile, Rail4Array[#Rail4Array])
                        table.remove(Rail4Array)
                    -- check if array is empty                    
                        if #Rail4Array == 0 then
                        Array1Touched,Array2Touched,Array3Touched,Array4Touched=false,false,false,false
                        Rail.Stack()
                        end
                    end 
            elseif DealNumber == 3 then
                    i = index1 -- source                
                    if i == 1 then
                        table.insert(WastePile, Rail1Array[#Rail1Array])
                        table.remove(Rail1Array)
                    elseif i == 2 then
                        table.insert(WastePile, Rail2Array[#Rail2Array])
                        table.remove(Rail2Array)
                    elseif i == 3 then
                        table.insert(WastePile, Rail3Array[#Rail3Array])
                        table.remove(Rail3Array)                    
                        if #Rail3Array == 0 then
                        Array1Touched,Array2Touched,Array3Touched=false,false,false
                        Rail.Stack()
                        end
                    end 
            
            elseif DealNumber == 4 then
                    i = index1 -- source                
                    if i == 1 then
                        table.insert(WastePile, Rail1Array[#Rail1Array])
                        table.remove(Rail1Array)
                    elseif i == 2 then
                        table.insert(WastePile, Rail2Array[#Rail2Array])
                        table.remove(Rail2Array)                 
                        if #Rail2Array == 0 then
                        Array1Touched,Array2Touched=false,false
                        Rail.Stack()
                        end
                    end 
            elseif DealNumber == 5 then
                    i = index1 -- source                
                    if i == 1 then
                        table.insert(WastePile, Rail1Array[#Rail1Array])
                        table.remove(Rail1Array)             
                        if #Rail1Array == 0 then
                        Array1Touched=false
                        Rail.Stack()
                        end
                    end 
            end
    end
end
    
function touched(touch)
    ReStart.touched(touch)
    Rules.touched(touch)
    for i,v in ipairs(AllPositions) do
        if touch.x > v.x - width*.5 and touch.x < v.x + width*.5
                and touch.y > v.y - height*.5 and touch.y < v.y + height*.5 then
            if touch.tapCount == 1 and touch.state == ENDED then
               index1 = i
                Rail.move(index1)
            end
        end
    end
end

function Deck.touched(touch)    --called in touched(touch)
    if touch.x > DeckPosition.x - width*.5 and touch.x < DeckPosition.x + width*.5
    and touch.y > DeckPosition.y - height*.5 and touch.y < DeckPosition.y + height*.5
    and touch.state == ENDED then
        if #Deck ~= 0 then
            if #Rail1Array == 0 or #Rail2Array == 0
                 or #Rail3Array == 0 or #Rail4Array == 0 or #Rail5Array == 0 then
                RailDealCheck()
            else
                Rail.deal() 
            end 
        end  
    end
end

function Rules.touched(touch)    --called in touched(touch)
    for i,v in ipairs(RulesPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
            alert(rules, "Game Rules")
            end
        end
    end
end

function ReStart.touched(touch) 
    for i,v in ipairs(ReStartPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
                for i = 1, #Rail1Array do
                    table.remove(Rail1Array)
                end
                    table.remove(Rail2Array,1)
                    table.remove(Rail3Array,1)
                    table.remove(Rail4Array,1)
                    table.remove(Rail5Array,1)
                for i = 1, #WastePile do
                    table.remove(WastePile)
                end
                Array1Touched = false
                Array2Touched = false
                Array3Touched = false
                Array4Touched = false
                Array5Touched = false
                rank1 = nil
                suit1 = nil
                RoyalSuit = nil
                DealNumber = 0
                GamesWon = readLocalData("GamesWon",0)
                GamesPlayed = readLocalData("GamesPlayed",0)
                Foundationinit = {0,13,26,39} -- initial foundation Ace cards
                RailTest = "Rail"
                DeckTest = "Deck"
                Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
                DisplayText = "Start: " 
                DisplayText2 = ""
                Deck.setup() -- setup the deck    
                Rail.deal() -- deal the cards to the rail
                GamesPlayed = GamesPlayed + 1  
                saveLocalData("GamesPlayed",GamesPlayed)   
                saved=true 
                WinnerTextSize = 10
                CardCount = 0
                KingCheck = false
                blanktest = 0
                GameWinCheck = 0
                rankTest1 = 0
                rankTest2 = 0
                rankTest3 = 0
                rankTest4 = 0
                rankTest5 = 0

            end
        end
    end
end
