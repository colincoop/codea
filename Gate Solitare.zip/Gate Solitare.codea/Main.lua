--~~~
-- Gate Solitare
--[[ Created by Colin Cooper,  1st October 2018
 5/10/18 updated to use table.insert for posts and rails
 10/10/18 added routing to check railarrays for empty slots and added mesh.clear in draw routines
         added collectgarbage() to draw function to stop codea crashing
 12/10/18 added test for RailArrays to see if each has no cards, and card being moved from post, 
            value of second card (index2 is calculated to allow move.)
            added math.floor to GamesWon and GamePlayed in display so that integers are dispalyed not floats
            added Rules button to screen instead of popup when game starts
 13/10/18  added explosion of cards at end of game
--]]

    supportedOrientations(WIDTH)
    displayMode(OVERLAY)
    displayMode( FULLSCREEN )

function setup()
rules = "Gate is played with a single deck of 52 cards, two columns of five cards act as the reserve or Gate Posts,  between these columns two rows of four cards are dealt. These compose the Rails or the tableau, the spaces for the foundations are allotted over the first row of cards. The object of the game, like many solitaire games, is to find the aces, place them on the foundations, and build each of them up by suit to Kings. The cards in the rails are available for play, to be placed on the foundations or on other cards in the rail. The cards in the rail are built down by alternating colour, (a card with a red suit over a card with a black suit) and visa versa. Spaces in the rail are filled using cards from the wastepile or the Deck if the wastepile is empty. Cards in the gate posts are never replenished, the stock can be dealt one card at a time to a wastepile. The top card of which is available for play, either to be placed in one of the foundations or to fill a gap on the rails, however, once the stock runs out, there are no redials. The game ends soon after the deck runs out, the game is won when all cards are played to the foundations"

    GamesWon = readLocalData("GamesWon",0)
    GamesPlayed = readLocalData("GamesPlayed",0)
    Foundationinit = {0,13,26,39} -- initial foundation Ace cards
    FirstDiamondAce = true
    FirstHeartAce = true
    FirstSpadeAce = true
    FirstClubAce = true
    RailTest = "Rail"
    PostTest = "Post"
    FoundationTest = "foundation"
    WastePileTest = "wastepile"
    Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
    DisplayText = "Start: " 
    DisplayText2 = ""
    Deck.setup() -- setup the deck    
    Rail.deal() -- deal the cards to the rail
    for i = 1, 10-#Post do    -- deal the cards on the posts
        if #Post <  10 and #Deck > 0 then Post.deal() end
    end
    Foundation.deal() -- setup the foundation cards
    GamesPlayed = GamesPlayed + 1  
    saveLocalData("GamesPlayed",GamesPlayed)   
    saved=true 
    WinnerTextSize = 10
    --explosions variables
    KingHearts=readImage("Documents:KingHearts")
    KingDiamonds=readImage("Documents:KingDiamonds")
    KingClubs=readImage("Documents:KingClubs")
    KingSpades=readImage("Documents:KingSpades")
    img=KingHearts   
    numSparks = 5
    damping = 1.01
    velocity = 0.3
    MODE = 1
    constant = true
    atTouch = false
    Rebound = true
    Xwind = 0
    Ywind = 0
    GRAVITY = 1.3
    explosions = {}
    origin = vec2(350,600)
    ExplosionWin = false
    -- end explosion variables

end

function draw()
    collectgarbage() 
    background(40,40,50,1)
    ReStart.draw()
    Rules.draw()
    Deck.draw()
    Post.draw()
    Foundation.draw()
    WastePile.draw()
    Letters.draw()
    Rail1Array.draw()
    Rail2Array.draw()
    Rail3Array.draw()
    Rail4Array.draw()
    Rail5Array.draw()
    Rail6Array.draw()
    Rail7Array.draw()
    Rail8Array.draw()
    if #Rail1Array+#Rail2Array+#Rail3Array+#Rail4Array+
        #Rail5Array+#Rail6Array+#Rail7Array+#Rail8Array+#Post+#WastePile+#Deck == 0  then
        if  saved then
        DisplayText = "Congratulations you have Won!  "
        GamesWon = GamesWon + 1
        saveLocalData("GamesWon",GamesWon)
        DisplayText2=""
        saved = false
        ExplosionWin = true
        end
            if ExplosionWin then

            -- explosions
                gravity = vec2(0,-GRAVITY)     
                wind = vec2(Xwind,Ywind)
--                blendMode(ADDITIVE)
                for i =1, #explosions do
                    explosions[i]:draw(gravity,wind)
                end
                    if #explosions >= 100 then
                        cullexplosions()
                        ExplosionWin = false
                    else
                        explosions[#explosions+1] = Sparks(origin.x,origin.y,numSparks,col,nil,70)
                        if #explosions < 25 then img=KingHearts
                        elseif #explosions <50 then img=KingSpades
                            elseif #explosions <75 then img=KingDiamonds
                                elseif #explosions <100 then img=KingClubs 
                        end                
                    end
                if WinnerTextSize>160 then
                    WinnerTextSize=160    
                    else
                    WinnerTextSize = WinnerTextSize+1
                end
                fill(255, 0, 0, 255)
                fontSize(WinnerTextSize)
                text( "WINNER!",WIDTH/2, HEIGHT/2 )
            end
    elseif  #Deck == 0 then
        DisplayText2 = "You have "..#Rail1Array+#Rail2Array+#Rail3Array+#Rail4Array+
        #Rail5Array+#Rail6Array+#Rail7Array+#Rail8Array+#Post+#WastePile.." Cards left: "
    end
end




-- Global variables
Deck = {}   --52 length array, holds cards in deck
Rail = {}  -- used to deal cards initially in the rail
Rules = {}
Rail1Array = {} --array to hold Rail index 1 cards when hidden by top card
Rail2Array = {} --array to hold Rail index 2 cards when hidden by top card
Rail3Array = {} --array to hold Rail index 3 cards when hidden by top card
Rail4Array = {} --array to hold Rail index 4 cards when hidden by top card
Rail5Array = {} --array to hold Rail index 5 cards when hidden by top card
Rail6Array = {} --array to hold Rail index 6 cards when hidden by top card
Rail7Array = {} --array to hold Rail index 7 cards when hidden by top card
Rail8Array = {} --array to hold Rail index 8 cards when hidden by top card
Post = {} -- 8 length array, for the gate Posts
Foundation = {} -- 4 length array for the foundation cards
WastePile = {} -- open ended array for the wastepile
ReStart = {}
WasteRail = {}
Letters = {}

local numberOfRanks = 13 -- Ace through to King
local numberOfSuits = 4
local width, height = 70,98  -- (50, 70) (70, 98) (80, 112) (90, 126) (100, 140)

local Rail1ArrayPosition = { vec2(250,450) }
local Rail2ArrayPosition = { vec2(350,450) }
local Rail3ArrayPosition = { vec2(450,450) }
local Rail4ArrayPosition = { vec2(550,450) }
local Rail5ArrayPosition = { vec2(250,200) }
local Rail6ArrayPosition = { vec2(350,200) }
local Rail7ArrayPosition = { vec2(450,200) }
local Rail8ArrayPosition = { vec2(550,200) }

local PostPosition = { 
    vec2(150,550), vec2(150,450), vec2(150,350), vec2(150,250), vec2(150,150),
    vec2(650,550), vec2(650,450), vec2(650,350), vec2(650,250), vec2(650,150) }

local FoundationPosition = { vec2(250,600), vec2(350,600), vec2(450,600), vec2(550,600) }

local WastePilePosition = { vec2(WIDTH-100, 368) }

local AllPositions = {  
    -- rail positions    
    vec2(250,450), vec2(350,450), vec2(450,450), vec2(550,450), 
    vec2(250,200), vec2(350,200), vec2(450,200), vec2(550,200),
    -- post positions
    vec2(150,550), vec2(150,450), vec2(150,350), vec2(150,250), vec2(150,150),
    vec2(650,550), vec2(650,450), vec2(650,350), vec2(650,250), vec2(650,150),
    -- foundation position
    vec2(250,600), vec2(350,600), vec2(450,600), vec2(550,600), vec2(WIDTH-100,368) }

local ReStartPosition = { vec2(WIDTH-100,HEIGHT-200) }

local RulesPosition = { vec2(WIDTH-100,HEIGHT-250) }

local DeckPosition =  vec2(WIDTH-100, 168) 

function Deck.setup()   --called in setup()
    for i = 1, 52 do
        Deck[i] = i
    end
    local j
    for i = 52, 2, -1 do
        j = math.random(52)
        Deck[i], Deck[j] = Deck[j], Deck[i]
    end
end

function Letters.draw()
        fontSize(14)
        fill(247, 247, 247, 255)
        text("Rails",WIDTH/2-100,HEIGHT/2)
        text("Rails",WIDTH/2-100,HEIGHT/2-250)
        text("P",700,480)  
        text("o",700,460) 
        text("s",700,440) 
        text("t",700,420)    
        text("P",100,480)  
        text("o",100,460) 
        text("s",100,440) 
        text("t",100,420) 
        text("Foundation",WIDTH/2-100,HEIGHT/2+150) 
        text("Deck #"..#Deck,WIDTH-100, 100)
        text("Wastepile #"..#WastePile,WIDTH-100, 300)  
        text(DisplayText,WIDTH/2,HEIGHT-40)
        text(DisplayText2,WIDTH/2,HEIGHT-80)
        text("You have won "..math.floor(GamesWon).." out of "..math.floor(GamesPlayed).." games",WIDTH/2,50)   
end

function ReStart.draw()
    local mesh = mesh()
        mesh:addRect(ReStartPosition[1].x, ReStartPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(255, 0, 0, 255)
    fontSize(14) 
    text('Restart', ReStartPosition[1].x, ReStartPosition[1].y)
end

function Rules.draw()
    local mesh = mesh()
        mesh:addRect(RulesPosition[1].x, RulesPosition[1].y, 60, 30)
    mesh:draw()
    mesh:clear()  
    fill(54, 148, 33, 255)
    fontSize(14) 
    text('Rules', RulesPosition[1].x, RulesPosition[1].y)
end

function WastePile.draw()
    local mesh=mesh()
    for i,v in ipairs(WastePile) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(WastePilePosition[1].x, WastePilePosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw()  
    mesh:clear()  
end

function Rail1Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail1Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail1ArrayPosition[1].x, Rail1ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail2Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail2Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail2ArrayPosition[1].x, Rail2ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw()
    mesh:clear()  
end

function Rail3Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail3Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail3ArrayPosition[1].x, Rail3ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail4Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail4Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail4ArrayPosition[1].x, Rail4ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail5Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail5Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail5ArrayPosition[1].x, Rail5ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail6Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail6Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail6ArrayPosition[1].x, Rail6ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail7Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail7Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail7ArrayPosition[1].x, Rail7ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Rail8Array.draw()
    local mesh=mesh()
    for i,v in ipairs(Rail8Array) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(Rail8ArrayPosition[1].x, Rail8ArrayPosition[1].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Post.draw()
    local mesh=mesh()
    for i,v in ipairs(Post) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(PostPosition[i].x, PostPosition[i].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw() 
    mesh:clear()  
end

function Deck.draw()
    local mesh = mesh()
        mesh.texture = "Documents:CardBack"
        mesh:addRect(DeckPosition.x, DeckPosition.y, width, height)
    mesh:draw()
    mesh:clear()  
    -- number of cards remaining in deck
    fill(8, 7, 7, 255)
    fontSize(32) 
    text('#'..#Deck, DeckPosition.x, DeckPosition.y)
end

function Foundation.draw()
    local mesh=mesh()
    for i,v in ipairs(Foundation) do --index determines position
        local rank = (1/numberOfRanks)*(v % numberOfRanks)
        local suit = (1/numberOfSuits)*(v % numberOfSuits)
        mesh.texture = "Documents:sheet"
        mesh:addRect(FoundationPosition[i].x, FoundationPosition[i].y, width, height)
        mesh:setRectTex(i, rank, suit, 1/numberOfRanks, 1/numberOfSuits)
    end
    mesh:draw()
    mesh:clear()  
    fontSize(75) 
        -- spades, hearts, diamonds, clubs 
        -- this prints the suit over the Aces in the foundation till an Ace is moved to the foundation
    if FirstSpadeAce == true then
    fill(12, 11, 11, 238)
    text('♠️', FoundationPosition[1].x, FoundationPosition[1].y)
    end
    if FirstClubAce then
    text('♣️', FoundationPosition[4].x, FoundationPosition[4].y)
    end
    if FirstHeartAce then -- removed == true
    fill(223, 17, 25, 238)
    text('♥️', FoundationPosition[2].x, FoundationPosition[2].y)
    end
    if FirstDiamondAce then
    text('♦️', FoundationPosition[3].x, FoundationPosition[3].y)
    end

end

function Rail.deal()   --called to placed cards in Rail
        if #Deck ~= 0 then
        Deck[#Deck], Rail1Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail2Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail3Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail4Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail5Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail6Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail7Array[1] = nil, Deck[#Deck]
        Deck[#Deck], Rail8Array[1] = nil, Deck[#Deck]
        end
end

function cullexplosions()
    for i=#explosions,1,-1 do
            table.remove(explosions,i)
    end
end

function Post.deal()
    if #Post < 10 and #Deck > 0 then
        Deck[#Deck], Post[#Post + 1] = nil, Deck[#Deck]
    end
end

 function Foundation.deal()
    for i = 1,4 do
        Foundation[i] =  Foundationinit[i]
    end
end

function WastePile.deal()   --called in Deck.touched(touch)
        Deck[#Deck], WastePile[#WastePile + 1] = nil, Deck[#Deck]
end

function RailDealCheck()
            if #Rail1Array == 0 then -- if pile empty deal card from waste or deck
                if #WastePile ~= 0 then
                table.insert(Rail1Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail1Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail2Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail2Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail2Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail3Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail3Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail3Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail4Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail4Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail4Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail5Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail5Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail5Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail6Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail6Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail6Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail7Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail7Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail7Array,Deck[#Deck])
                table.remove(Deck)
                end
            elseif #Rail8Array == 0 then
                if #WastePile ~= 0 then
                table.insert(Rail8Array,WastePile[#WastePile])
                table.remove(WastePile)
                else
                table.insert(Rail8Array,Deck[#Deck])
                table.remove(Deck)
                end
            end
end

-- Rail.move defines the game rules,  During a move, the card originally at index 2 is elimnated from the game
-- index1 and index2 are passed from the touch routines, ranks and suits are determined, tests are done to ensure
-- that the move is permitted.

-- when railarray is empty and post moves a card, index2 fails as no value to lookup, need to code a test of railarray length, and allow the move

function Rail.move(index1, index2) --called in Rail.touched(touch)
    --index one, assignment of rank1 and suit1

    if index1 == 1 then
        --Rail1Array
        rank1, suit1 = Rail1Array[#Rail1Array]%numberOfRanks, Rail1Array[#Rail1Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 2 then
        --Rail2Array
        rank1, suit1 = Rail2Array[#Rail2Array]%numberOfRanks, Rail2Array[#Rail2Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 3 then
        --Rail3Array
        rank1, suit1 = Rail3Array[#Rail3Array]%numberOfRanks, Rail3Array[#Rail3Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 4 then
        --Rail4Array
        rank1, suit1 = Rail4Array[#Rail4Array]%numberOfRanks, Rail4Array[#Rail4Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 5 then
        --Rail5Array
        rank1, suit1 = Rail5Array[#Rail5Array]%numberOfRanks, Rail5Array[#Rail5Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 6 then
        --Rail6Array
        rank1, suit1 = Rail6Array[#Rail6Array]%numberOfRanks, Rail6Array[#Rail6Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 7 then
        --Rail7Array
        rank1, suit1 = Rail7Array[#Rail7Array]%numberOfRanks, Rail7Array[#Rail7Array]%numberOfSuits
        CardOrigin = RailTest
    elseif index1 == 8 then
        --Rail8Array
        rank1, suit1 = Rail8Array[#Rail8Array]%numberOfRanks, Rail8Array[#Rail8Array]%numberOfSuits
        CardOrigin = RailTest        
    elseif index1 >= 9 and index1 <= 18 then
        -- Post
        rank1, suit1 = Post[index1-8]%numberOfRanks, Post[index1-8]%numberOfSuits
        CardOrigin = PostTest
    elseif index1 == 23 then
        -- wastepile
        rank1, suit1 = WastePile[#WastePile]%numberOfRanks, WastePile[#WastePile]%numberOfSuits
        CardOrigin = WastePileTest
    end
    --index two assignment of rank2 and suit2
    if index2 == 1 then
        --Rail1Array
        if #Rail1Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail1Array[#Rail1Array]%numberOfRanks, Rail1Array[#Rail1Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 2 then
        --Rail2Array
        if #Rail2Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail2Array[#Rail2Array]%numberOfRanks, Rail2Array[#Rail2Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 3 then
        --Rail3Array
        if #Rail3Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail3Array[#Rail3Array]%numberOfRanks, Rail3Array[#Rail3Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 4 then
        --Rail4Array
        if #Rail4Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail4Array[#Rail4Array]%numberOfRanks, Rail4Array[#Rail4Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 5 then
        --Rail5Array
        if #Rail5Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail5Array[#Rail5Array]%numberOfRanks, Rail5Array[#Rail5Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 6 then
        --Rail6Array
        if #Rail6Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail6Array[#Rail6Array]%numberOfRanks, Rail6Array[#Rail6Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 7 then
        --Rail7Array
        if #Rail7Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail7Array[#Rail7Array]%numberOfRanks, Rail7Array[#Rail7Array]%numberOfSuits
        CardDestination = RailTest
        end
    elseif index2 == 8 then
        --Rail8Array
        if #Rail8Array == 0 then 
         rank2 = rank1+1
            if suit1==0 then suit2=1
            elseif suit1==1 then suit2=0
            elseif suit1==2 then suit2=3
            elseif suit1==3 then suit2=2
             end
        else
        rank2, suit2 = Rail8Array[#Rail8Array]%numberOfRanks, Rail8Array[#Rail8Array]%numberOfSuits
        CardDestination = RailTest
        end
              
    elseif index2 >= 9 and index2 <= 18 then        
        -- Post
        if index2 > #Post then
          DisplayText = "Invalid move : cant move cards to post"  
        else
        rank2, suit2 = Post[index2-8]%numberOfRanks, Post[index2-8]%numberOfSuits
        CardDestination = PostTest
        end
    elseif index2 >= 19 and index2 <= 22 then
        -- foundation
        rank2, suit2 = Foundation[index2-18]%numberOfRanks, Foundation[index2-18]%numberOfSuits
        CardDestination = FoundationTest 
    end

-- these test if movement of the card is permitted    
--test one
if index1 == 23 and index2 >= 9 and index2 <= 18 then 
       DisplayText = "Invalid Move: Wastepile cards cannot be moved to the post"
        Test1 = 1
elseif index1 >= 9 and index1 <= 18 and index2 >= 9 and index2 <= 18 then
       DisplayText = "Invalid Move: Post cards cannot be moved to the Post" 
        Test1 = 1     
--test two
elseif FirstClubAce == true and rank1 ~= 0 and suit2 == 3 or FirstSpadeAce == true and rank1 ~= 0 and suit2 == 0 or FirstHeartAce == true and rank1 ~= 0 and suit2 == 1 or FirstDiamondAce == true and rank1 ~= 0 and suit2 == 2 then
        if index2 >= 19 and index2 <= 22 then
        DisplayText = "Invalid Move: Aces must be moved first"  
        Test2 = 1
        end  

-- test three
elseif CardDestination == FoundationTest and rank1 ~= rank2+1 and rank1 ~= 0 or CardDestination == FoundationTest and suit1 ~= suit2 then
            DisplayText = "Invalid Move. card suits must match or the card rank must be one card higher." 
            Test3 = 1            
end
        
-- test four                
if CardDestination == RailTest then
        if rank1 == rank2-1 then
                -- spades, hearts, diamonds, clubs 
            if suit1 == 0 and suit2 == 3
                    or suit1 == 3 and suit2 == 0
                    or suit1 == 1 and suit2 == 2
                    or suit1 == suit2
                    or suit1 == 2 and suit2 == 1 then
            DisplayText = "Invalid Move. card suits must be Red/Black or Black/Red, and the card must one lower" 
            Test4 = 1
            end
        else
            DisplayText = "Invalid Move. card suits must be Red/Black or Black/Red, and the card must one lower" 
            Test5 = 1
        end
end
    
if Test1+Test2+Test3+Test4+Test5>0 then
-- if any test returns a 1 then the card moving routine does not activate        

        Test1, Test2, Test3, Test4, Test5 = 0,0,0,0,0   -- reset the tests  
                     
else -- move the cards
        DisplayText = ""
            RailFilled = 0
            if CardOrigin == RailTest then
                    if CardDestination == RailTest then
-- origin Rail destination Rail
                    i = index1 -- source
                    j = index2 -- destination
                        if j == 1 then
                                if i == 2 then
                                table.insert(Rail1Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail1Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail1Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail1Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail1Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail1Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail1Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 2 then
                                if i == 1 then
                                table.insert(Rail2Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 3 then
                                table.insert(Rail2Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail2Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail2Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail2Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail2Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail2Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 3 then
                                if i == 1 then
                                table.insert(Rail3Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail3Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 4 then
                                table.insert(Rail3Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail3Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail3Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail3Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail3Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 4 then
                                if i == 1 then
                                table.insert(Rail4Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail4Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail4Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 5 then
                                table.insert(Rail4Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail4Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail4Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail4Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 5 then
                                if i == 1 then
                                table.insert(Rail5Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail5Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail5Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail5Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 6 then
                                table.insert(Rail5Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail5Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail5Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 6 then
                                if i == 1 then
                                table.insert(Rail6Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail6Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail6Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail6Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail6Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 7 then
                                table.insert(Rail6Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                table.insert(Rail6Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 7 then
                                if i == 1 then
                                table.insert(Rail7Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail7Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail7Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail7Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail7Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail7Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 8 then
                                table.insert(Rail7Array,Rail8Array[#Rail8Array])
                                table.remove(Rail8Array)
                                end
                        elseif j == 8 then
                                if i == 1 then
                                table.insert(Rail8Array,Rail1Array[#Rail1Array])
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                table.insert(Rail8Array,Rail2Array[#Rail2Array])
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                table.insert(Rail8Array,Rail3Array[#Rail3Array])
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                table.insert(Rail8Array,Rail4Array[#Rail4Array])
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                table.insert(Rail8Array,Rail5Array[#Rail5Array])
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                table.insert(Rail8Array,Rail6Array[#Rail6Array])
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                table.insert(Rail8Array,Rail7Array[#Rail7Array])
                                table.remove(Rail7Array)
                                end
                        end  
                RailDealCheck()     

            elseif CardDestination == FoundationTest then
                    -- origin Rail destination foundation 

                    i = index1 -- source
                    j = index2-18 -- destination
                        if j == 1 then
                                if i == 1 then
                                Foundation[1] = Rail1Array[#Rail1Array]
                                FirstSpadeAce = false
                                table.remove(Rail1Array)
                                elseif i == 2 then 
                                Foundation[1] = Rail2Array[#Rail2Array]
                                FirstSpadeAce = false
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                Foundation[1] = Rail3Array[#Rail3Array]
                                FirstSpadeAce = false
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                Foundation[1] = Rail4Array[#Rail4Array]
                                FirstSpadeAce = false
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                Foundation[1] = Rail5Array[#Rail5Array]
                                FirstSpadeAce = false
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                Foundation[1] = Rail6Array[#Rail6Array]
                                FirstSpadeAce = false
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                Foundation[1] = Rail7Array[#Rail7Array]
                                FirstSpadeAce = false
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                Foundation[1] = Rail8Array[#Rail8Array]
                                FirstSpadeAce = false
                                table.remove(Rail8Array)
                                end
                    elseif j == 2 then
                                if i == 1 then
                                Foundation[2] = Rail1Array[#Rail1Array]
                                FirstHeartAce = false
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                Foundation[2] = Rail2Array[#Rail2Array]
                                FirstHeartAce = false
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                Foundation[2] = Rail3Array[#Rail3Array]
                                FirstHeartAce = false
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                Foundation[2] = Rail4Array[#Rail4Array]
                                FirstHeartAce = false
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                Foundation[2] = Rail5Array[#Rail5Array]
                                FirstHeartAce = false
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                Foundation[2] = Rail6Array[#Rail6Array]
                                FirstHeartAce = false
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                Foundation[2] = Rail7Array[#Rail7Array]
                                FirstHeartAce = false
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                Foundation[2] = Rail8Array[#Rail8Array]
                                FirstHeartAce = false
                                table.remove(Rail8Array)
                                end
                    elseif j == 3 then
                                if i == 1 then
                                Foundation[3] = Rail1Array[#Rail1Array]
                                FirstDiamondAce = false
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                Foundation[3] = Rail2Array[#Rail2Array]
                                FirstDiamondAce = false
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                Foundation[3] = Rail3Array[#Rail3Array]
                                FirstDiamondAce = false
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                Foundation[3] = Rail4Array[#Rail4Array]
                                FirstDiamondAce = false
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                Foundation[3] = Rail5Array[#Rail5Array]
                                FirstDiamondAce = false
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                Foundation[3] = Rail6Array[#Rail6Array]
                                FirstDiamondAce = false
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                Foundation[3] = Rail7Array[#Rail7Array]
                                FirstDiamondAce = false
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                Foundation[3] = Rail8Array[#Rail8Array]
                                FirstDiamondAce = false
                                table.remove(Rail8Array)
                                end
                    elseif j == 4 then
                                if i == 1 then
                                Foundation[4] = Rail1Array[#Rail1Array]
                                FirstClubAce = false
                                table.remove(Rail1Array)
                                elseif i == 2 then
                                Foundation[4] = Rail2Array[#Rail2Array]
                                FirstClubAce = false
                                table.remove(Rail2Array)
                                elseif i == 3 then
                                Foundation[4] = Rail3Array[#Rail3Array]
                                FirstClubAce = false
                                table.remove(Rail3Array)
                                elseif i == 4 then
                                Foundation[4] = Rail4Array[#Rail4Array]
                                FirstClubAce = false
                                table.remove(Rail4Array)
                                elseif i == 5 then
                                Foundation[4] = Rail5Array[#Rail5Array]
                                FirstClubAce = false
                                table.remove(Rail5Array)
                                elseif i == 6 then
                                Foundation[4] = Rail6Array[#Rail6Array]
                                FirstClubAce = false
                                table.remove(Rail6Array)
                                elseif i == 7 then
                                Foundation[4] = Rail7Array[#Rail7Array]
                                FirstClubAce = false
                                table.remove(Rail7Array)
                                elseif i == 8 then
                                Foundation[4] = Rail8Array[#Rail8Array]
                                FirstClubAce = false
                                table.remove(Rail8Array)
                                end
                    
                        end
                RailDealCheck()

                end
            
            elseif CardOrigin == PostTest then            
                if CardDestination == RailTest then
-- origin Post destination Rail
                    i = index1-8
                    j = index2
                
                    if j == 1 then
                            table.insert(Rail1Array,Post[i])
                    elseif j == 2 then
                            table.insert(Rail2Array,Post[i])
                    elseif j == 3 then
                            table.insert(Rail3Array,Post[i])
                    elseif j == 4 then
                            table.insert(Rail4Array,Post[i])
                    elseif j == 5 then
                            table.insert(Rail5Array,Post[i])
                    elseif j == 6 then
                            table.insert(Rail6Array,Post[i])
                    elseif j == 7 then
                            table.insert(Rail7Array,Post[i])
                    elseif j == 8 then
                            table.insert(Rail8Array,Post[i])
                    end               
                    table.remove(Post, i)
 
                elseif CardDestination == FoundationTest then
-- origin Post destination foundation
                    i = index1-8
                    if suit2 == 0 then -- spade
                        Foundation[1] = Post[i]
                        FirstSpadeAce = false
                    elseif suit2 == 1 then -- hearts
                        Foundation[2] = Post[i]
                        FirstHeartAce = false
                    elseif suit2 == 2 then -- diamond
                        Foundation[3] = Post[i]
                        FirstDiamondAce = false
                    elseif suit2 == 3 then -- club
                        Foundation[4] = Post[i]
                        FirstClubAce = false
                    end
                    table.remove(Post, i)
                end
            
            elseif CardOrigin == WastePileTest then
                if CardDestination == RailTest then
-- origin wastepile destination Rail
                    i = index2
                    if i == 1 then
                        table.insert(Rail1Array,WastePile[#WastePile])
                    elseif i == 2 then
                        table.insert(Rail2Array,WastePile[#WastePile])
                    elseif i == 3 then
                        table.insert(Rail3Array,WastePile[#WastePile])
                    elseif i == 4 then
                        table.insert(Rail4Array,WastePile[#WastePile])
                    elseif i == 5 then
                        table.insert(Rail5Array,WastePile[#WastePile])
                    elseif i == 6 then
                        table.insert(Rail6Array,WastePile[#WastePile])
                    elseif i == 7 then
                        table.insert(Rail7Array,WastePile[#WastePile])
                    elseif i == 8 then
                        table.insert(Rail8Array,WastePile[#WastePile])
                    end               
                    table.remove(WastePile, #WastePile)
                
                elseif CardDestination == FoundationTest then
-- origin wastepile destination foundation
                    if suit2 == 0 then -- spade
                        Foundation[1] = WastePile[#WastePile]
                        FirstSpadeAce = false
                    elseif suit2 == 1 then -- hearts
                        Foundation[2] = WastePile[#WastePile]
                        FirstHeartAce = false
                    elseif suit2 == 2 then -- diamond
                        Foundation[3] = WastePile[#WastePile]
                        FirstDiamondAce = false
                    elseif suit2 == 3 then -- club
                        Foundation[4] = WastePile[#WastePile]
                        FirstClubAce = false
                    end
                    table.remove(WastePile, #WastePile)
                end
            end
        end
    end



function touched(touch)
    ReStart.touched(touch)
    Rules.touched(touch)
    Deck.touched(touch)
    for i,v in ipairs(AllPositions) do
        if touch.x > v.x - width*.5 and touch.x < v.x + width*.5
        and touch.y > v.y - height*.5 and touch.y < v.y + height*.5 then
            if touch.state == BEGAN then
                index1 = i
                break
            elseif touch.state == ENDED then
                index2 = i
                if index1 and index2 and index1 ~= index2 then
                    Rail.move(index1, index2)
                end
                index1, index2 = nil, nil
                break
            end
        end
    end

end

function Deck.touched(touch)    --called in touched(touch)
    if touch.x > DeckPosition.x - width*.5 and touch.x < DeckPosition.x + width*.5
    and touch.y > DeckPosition.y - height*.5 and touch.y < DeckPosition.y + height*.5
    and touch.state == ENDED then
        if #Deck ~= 0 then
        WastePile.deal()  
        end  
    end
end

function Rules.touched(touch)    --called in touched(touch)
    for i,v in ipairs(RulesPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
            alert(rules, "Game Rules")
            end
        end
    end
end

function ReStart.touched(touch) 
    for i,v in ipairs(ReStartPosition) do
        if touch.x > v.x - 30 and touch.x < v.x + 30
        and touch.y > v.y - 15 and touch.y < v.y + 15 then
            if touch.tapCount == 1 and touch.state == ENDED then
                if #Deck == 0 then
    GamesWon = readLocalData("GamesWon",0)
    GamesPlayed = readLocalData("GamesPlayed",0)
                    Foundationinit = {0,13,26,39} -- initial foundation Ace cards
                    for i = 1, #Post do
                        table.remove(Post)
                    end
                    for i = 1, #Rail1Array do
                        table.remove(Rail1Array)
                    end
                    for i = 1, #Rail2Array do
                        table.remove(Rail2Array)
                    end
                    for i = 1, #Rail3Array do
                        table.remove(Rail3Array)
                    end
                    for i = 1, #Rail4Array do
                        table.remove(Rail4Array)
                    end
                    for i = 1, #Rail5Array do
                        table.remove(Rail5Array)
                    end
                    for i = 1, #Rail6Array do
                        table.remove(Rail6Array)
                    end
                    for i = 1, #Rail7Array do
                        table.remove(Rail7Array)
                    end
                    for i = 1, #Rail8Array do
                        table.remove(Rail8Array)
                    end
                    for i = 1, #WastePile do
                        table.remove(WastePile)
                    end
                    for i = 1, #Deck do
                        table.remove(Deck)
                    end
                    FirstDiamondAce = true
                    FirstHeartAce = true
                    FirstSpadeAce = true
                    FirstClubAce = true
                    RailTest = "Rail"
                    PostTest = "Post"
                    FoundationTest = "foundation"
                    WastePileTest = "wastepile"
                    Test1 = 0 ; Test2 = 0  ; Test3 = 0 ; Test4 = 0 ; Test5 = 0
                    DisplayText = "Start: " 
                    Deck.setup() -- setup the deck
                    -- deal the cards to the rail
                    Rail.deal(i)
                    -- deal the cards on the posts
                    for i = 1, 10-#Post do
                        if #Post <  10 and #Deck > 0 then
                            Post.deal()
                        end
                    end
                    -- setup the foundation cards
                    saved=true 
                    WinnerTextSize = 10
                    Foundation.deal()
                    GamesPlayed = GamesPlayed + 1 
                    saveLocalData("GamesPlayed",GamesPlayed)  
                    ExplosionWin = false
                else
                        DisplayText = "Finish your game before restarting"
                end
            end
        end
    end
end

--~~~